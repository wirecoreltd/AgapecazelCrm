-- À exécuter dans Supabase > SQL Editor
create table branches (id uuid primary key default gen_random_uuid(), nom text not null, created_at timestamptz default now());

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nom_complet text,
  role text not null check (role in ('admin','agent','branch')),
  branch_id uuid references branches(id),
  constraint branch_requires_branch_id check (role <> 'branch' or branch_id is not null)
);

create table leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(), updated_at timestamptz default now(),
  created_by uuid references auth.users(id),
  civilite text not null check (civilite in ('M','Mme')),
  prenom text, nom text,
  adresse text not null, code_postal text not null, ville text not null,
  mobile text not null, telephone_1 text not null, telephone_2 text,
  proprietaire boolean not null,
  nb_personnes int not null check (nb_personnes > 0),
  revenus text, maison_plus_15_ans boolean,
  type_habitat text check (type_habitat in ('maison','appartement')),
  surface_habitable numeric not null check (surface_habitable > 0),
  chauffage text not null, produit_1 text,
  statut text not null default 'nouveau' check (statut in ('nouveau','transmis','rdv_pris','devis','signe','perdu')),
  branch_id uuid references branches(id)
);
create index on leads (branch_id);
create index on leads (statut);

create table lead_events (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  created_at timestamptz default now(),
  user_id uuid references auth.users(id),
  type text not null check (type in ('creation','statut','transmission')),
  ancien_statut text, nouveau_statut text,
  ancienne_branche uuid references branches(id), nouvelle_branche uuid references branches(id)
);
create index on lead_events (lead_id, created_at desc);

create function public.my_role() returns text language sql stable security definer set search_path = public
  as $$ select role from profiles where id = auth.uid() $$;
create function public.my_branch() returns uuid language sql stable security definer set search_path = public
  as $$ select branch_id from profiles where id = auth.uid() $$;

alter table branches enable row level security;
alter table profiles enable row level security;
alter table leads enable row level security;
alter table lead_events enable row level security;

create policy "lecture branches" on branches for select using (auth.uid() is not null);
create policy "lecture profil" on profiles for select using (id = auth.uid() or my_role() = 'admin');
create policy "cc voit tout" on leads for select using (my_role() in ('admin','agent'));
create policy "branche voit ses leads" on leads for select using (my_role() = 'branch' and branch_id = my_branch());
create policy "cc cree" on leads for insert with check (my_role() in ('admin','agent'));
create policy "cc modifie" on leads for update using (my_role() in ('admin','agent'));
create policy "branche modifie" on leads for update
  using (my_role() = 'branch' and branch_id = my_branch())
  with check (my_role() = 'branch' and branch_id = my_branch());
create policy "lecture events" on lead_events for select using (exists (select 1 from leads l where l.id = lead_id));

-- Une branche ne peut modifier que le statut
create function public.restrict_branch_updates() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if my_role() = 'branch' and (to_jsonb(new) - 'statut' - 'updated_at') is distinct from (to_jsonb(old) - 'statut' - 'updated_at') then
    raise exception 'Une branche ne peut modifier que le statut';
  end if;
  new.updated_at = now();
  return new;
end $$;
create trigger leads_restrict_branch before update on leads for each row execute function restrict_branch_updates();

-- Historique automatique
create function public.log_lead_events() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    insert into lead_events (lead_id, user_id, type, nouveau_statut, nouvelle_branche) values (new.id, auth.uid(), 'creation', new.statut, new.branch_id);
  else
    if new.statut is distinct from old.statut then
      insert into lead_events (lead_id, user_id, type, ancien_statut, nouveau_statut) values (new.id, auth.uid(), 'statut', old.statut, new.statut);
    end if;
    if new.branch_id is distinct from old.branch_id then
      insert into lead_events (lead_id, user_id, type, ancienne_branche, nouvelle_branche) values (new.id, auth.uid(), 'transmission', old.branch_id, new.branch_id);
    end if;
  end if;
  return new;
end $$;
create trigger leads_log_events after insert or update on leads for each row execute function log_lead_events();

-- Après avoir créé un utilisateur dans Authentication > Users :
-- insert into branches (nom) values ('Branche Nord');
-- insert into profiles (id, nom_complet, role) values ('<uuid-user>', 'Admin', 'admin');
-- Compte branche : role = 'branch' et branch_id = <uuid-branche>
